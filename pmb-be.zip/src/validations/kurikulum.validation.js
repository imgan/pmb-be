const Joi = require('joi');

const createKurikulum = Joi.object({
  kode: Joi.string().max(30).required(),
  mataKuliah: Joi.string().max(200).required(),
  sksTeori: Joi.number().integer().min(0).default(0),
  sksPraktek: Joi.number().integer().min(0).default(0),
  sksLab: Joi.number().integer().min(0).default(0),
  sksSimulasi: Joi.number().integer().min(0).default(0),
  semester: Joi.number().integer().min(1).max(14).allow(null),
  bidangMinat: Joi.number().integer().min(0).default(0),
  tahunAkademik: Joi.number().integer().allow(null),
});

const updateKurikulum = Joi.object({
  kode: Joi.string().max(30),
  mataKuliah: Joi.string().max(200),
  sksTeori: Joi.number().integer().min(0),
  sksPraktek: Joi.number().integer().min(0),
  sksLab: Joi.number().integer().min(0),
  sksSimulasi: Joi.number().integer().min(0),
  semester: Joi.number().integer().min(1).max(14).allow(null),
  bidangMinat: Joi.number().integer().min(0),
  tahunAkademik: Joi.number().integer().allow(null),
}).min(1);

module.exports = { createKurikulum, updateKurikulum };
