const Joi = require('joi');

const JENIS_SURAT_VALUES = ['AKTIF_KULIAH', 'LULUS_MENUNGGU_IJAZAH'];

const createSurat = Joi.object({
  mahasiswaId: Joi.number().integer().required(),
  jenisSurat: Joi.string().valid(...JENIS_SURAT_VALUES).required(),
  nomorSurat: Joi.string().max(100).allow('', null),
  tanggalInput: Joi.date().required(),
  semester: Joi.number().integer().min(1).max(20).allow(null),
  alasan: Joi.string().allow('', null),
});

const updateSurat = Joi.object({
  mahasiswaId: Joi.number().integer(),
  jenisSurat: Joi.string().valid(...JENIS_SURAT_VALUES),
  nomorSurat: Joi.string().max(100).allow('', null),
  tanggalInput: Joi.date(),
  semester: Joi.number().integer().min(1).max(20).allow(null),
  alasan: Joi.string().allow('', null),
}).min(1);

module.exports = { createSurat, updateSurat, JENIS_SURAT_VALUES };
