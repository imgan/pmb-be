module.exports = (sequelize, DataTypes) => {
  const Kurikulum = sequelize.define(
    'Kurikulum',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
      kode: { type: DataTypes.STRING(30), allowNull: false },
      mataKuliah: { type: DataTypes.STRING(200), allowNull: false },
      sksTeori: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      sksPraktek: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      sksLab: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      sksSimulasi: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      semester: { type: DataTypes.INTEGER, allowNull: true },
      bidangMinat: { type: DataTypes.INTEGER, allowNull: false, defaultValue: 0 },
      tahunAkademik: { type: DataTypes.INTEGER, allowNull: true },
      sksTotal: {
        type: DataTypes.VIRTUAL,
        get() {
          return (this.sksTeori ?? 0) + (this.sksPraktek ?? 0) + (this.sksLab ?? 0) + (this.sksSimulasi ?? 0);
        },
      },
      isDelete: { type: DataTypes.BOOLEAN, allowNull: false, defaultValue: false },
      createdBy: { type: DataTypes.INTEGER, allowNull: true },
      updatedBy: { type: DataTypes.INTEGER, allowNull: true },
    },
    {
      tableName: 'kurikulum',
      underscored: true,
      timestamps: true,
      defaultScope: { where: { isDelete: false } },
      scopes: { withDeleted: {} },
    }
  );

  Kurikulum.associate = (models) => {
    Kurikulum.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
    Kurikulum.belongsTo(models.User, { foreignKey: 'updatedBy', as: 'updater' });
  };

  return Kurikulum;
};
