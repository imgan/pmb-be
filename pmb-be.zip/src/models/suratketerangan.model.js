module.exports = (sequelize, DataTypes) => {
  const SuratKeterangan = sequelize.define(
    'SuratKeterangan',
    {
      id: { type: DataTypes.INTEGER, primaryKey: true, autoIncrement: true },
      mahasiswaId: { type: DataTypes.INTEGER, allowNull: false },
      jenisSurat: { type: DataTypes.STRING(50), allowNull: false },
      nomorSurat: { type: DataTypes.STRING(100), allowNull: true },
      tanggalInput: { type: DataTypes.DATEONLY, allowNull: false },
      semester: { type: DataTypes.INTEGER, allowNull: true },
      alasan: { type: DataTypes.TEXT, allowNull: true },
      createdBy: { type: DataTypes.INTEGER, allowNull: true },
      updatedBy: { type: DataTypes.INTEGER, allowNull: true },
    },
    {
      tableName: 'surat_keterangan',
      underscored: true,
      timestamps: true,
    }
  );

  SuratKeterangan.associate = (models) => {
    SuratKeterangan.belongsTo(models.Mahasiswa, { foreignKey: 'mahasiswaId', as: 'mahasiswa' });
    SuratKeterangan.belongsTo(models.User, { foreignKey: 'createdBy', as: 'creator' });
    SuratKeterangan.belongsTo(models.User, { foreignKey: 'updatedBy', as: 'updater' });
  };

  return SuratKeterangan;
};
