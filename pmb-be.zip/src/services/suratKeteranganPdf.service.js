const PDFDocument = require('pdfkit');

const MONTHS_ID = [
  'Januari', 'Februari', 'Maret', 'April', 'Mei', 'Juni',
  'Juli', 'Agustus', 'September', 'Oktober', 'November', 'Desember',
];
const ROMAN_MONTHS = ['I', 'II', 'III', 'IV', 'V', 'VI', 'VII', 'VIII', 'IX', 'X', 'XI', 'XII'];
const SEMESTER_WORDS = [
  '', 'satu', 'dua', 'tiga', 'empat', 'lima', 'enam', 'tujuh', 'delapan', 'sembilan', 'sepuluh',
  'sebelas', 'dua belas', 'tiga belas', 'empat belas',
];

const RECTOR_NAME = 'Dr. Ns. Desrinah Harahap, M.Kep., Sp.Kep.Mat';
const CITY_NAME = 'Bekasi';

const longDate = (value) => {
  if (!value) return '-';
  const d = new Date(value);
  if (Number.isNaN(d.getTime())) return '-';
  return `${d.getDate()} ${MONTHS_ID[d.getMonth()]} ${d.getFullYear()}`;
};

const semesterLabel = (semester) => {
  if (!semester) return '-';
  const word = SEMESTER_WORDS[semester] ?? '';
  return word ? `${semester} (${word})` : String(semester);
};

const tahunAkademik = (value) => {
  const d = value ? new Date(value) : new Date();
  const year = d.getFullYear();
  return d.getMonth() >= 6 ? `${year}/${year + 1}` : `${year - 1}/${year}`;
};

const nomorSuratLabel = (nomorSurat, tanggalInput) => {
  if (nomorSurat) return nomorSurat;
  const d = tanggalInput ? new Date(tanggalInput) : new Date();
  return `/AK/BAAK-UBS/${ROMAN_MONTHS[d.getMonth()]}/${d.getFullYear()}`;
};

const CONTENT_WIDTH = 595.28 - 56 * 2;

const kv = (doc, label, value, { labelWidth = 150 } = {}) => {
  const left = doc.page.margins.left;
  const y = doc.y;
  const valueX = left + labelWidth + 14;
  const valueWidth = left + CONTENT_WIDTH - valueX;
  doc.text(label, left, y, { width: labelWidth, lineBreak: false });
  doc.text(':', left + labelWidth, y, { width: 10, lineBreak: false });
  doc.text(String(value ?? '-'), valueX, y, { width: valueWidth });
  doc.x = left;
  doc.moveDown(0.3);
};

const buildSuratKeteranganPdf = (data) => {
  const { surat, mahasiswa, jurusan } = data;
  const doc = new PDFDocument({ size: 'A4', margin: 56, bufferPages: true });

  doc.font('Times-Bold').fontSize(14).text('SURAT KETERANGAN', { align: 'center' });
  doc.moveDown(0.15);
  doc.fontSize(9).text('-'.repeat(80), { align: 'center' });
  doc.font('Times-Bold').fontSize(10).text(`Nomor : ${nomorSuratLabel(surat.nomorSurat, surat.tanggalInput)}`, { align: 'center' });
  doc.font('Times-Roman').fontSize(11);
  doc.moveDown(1);

  doc.text('Yang bertanda tangan dibawah ini Rektor Universitas Bani Saleh dengan ini menerangkan bahwa :');
  doc.moveDown(0.6);

  kv(doc, 'Nama', mahasiswa.namaLengkap);
  kv(doc, 'NIM', mahasiswa.nim);
  kv(doc, 'NIK', mahasiswa.noKtp ?? '-');
  kv(doc, 'Prodi', jurusan?.namaJurusan ?? '-');
  kv(doc, 'Semester', semesterLabel(surat.semester));
  kv(doc, 'Tempat/Tanggal Lahir', `${mahasiswa.tempatLahir ?? '-'}, ${longDate(mahasiswa.tanggalLahir)}`);
  kv(doc, 'Alamat', mahasiswa.alamat ?? '-');

  doc.moveDown(0.8);

  const akademikYear = tahunAkademik(surat.tanggalInput);

  if (surat.jenisSurat === 'LULUS_MENUNGGU_IJAZAH') {
    doc.text(
      `Adalah benar mahasiswa aktif semester ${surat.semester ?? '-'} Program ${jurusan?.jenjangPendidikan ?? '-'} Program Studi ${jurusan?.namaJurusan ?? '-'} di Universitas Bani Saleh pada tahun akademik ${akademikYear}, yang sudah dinyatakan lulus dan ijazah beserta transkrip nilai sedang dalam proses.`
    );
  } else {
    doc.text('Adalah benar pada saat ini yang bersangkutan ', { continued: true, underline: false });
    doc.font('Times-Bold').text('aktif', { continued: true, underline: true });
    doc.font('Times-Roman').text(
      ` sebagai mahasiswa di Program Studi ${jurusan?.namaJurusan ?? '-'} Fakultas ${jurusan?.namaFakultas ?? '-'} Universitas Bani Saleh tahun akademik ${akademikYear}.`,
      { underline: false }
    );
  }

  doc.moveDown(0.8);
  if (surat.alasan) {
    doc.text(`Surat keterangan ini dibuat sebagai ${surat.alasan}.`);
    doc.moveDown(0.6);
  }
  doc.text('Demikian surat keterangan ini buat dengan sebenar - benarnya untuk dapat dipergunakan sebagaimana mestinya.');

  doc.moveDown(2);
  doc.text(`${CITY_NAME}, ${longDate(surat.tanggalInput)}`, { align: 'right' });
  doc.text('Rektor', { align: 'right' });
  doc.moveDown(3);
  doc.font('Times-Bold').text(RECTOR_NAME, { align: 'right', underline: true });
  doc.font('Times-Roman');

  doc.moveDown(2);
  doc.text('Tembusan :');
  doc.text('1. Pertinggal');

  doc.end();
  return doc;
};

module.exports = { buildSuratKeteranganPdf };
