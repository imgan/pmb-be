const { Op } = require('sequelize');
const { Kurikulum } = require('../models');
const ApiError = require('../utils/ApiError');
const { getPagination, getPagingMeta } = require('../utils/pagination');
const { resolveOrder } = require('../utils/sorting');

const SORTABLE_COLUMNS = {
  kode: ['kode'],
  mataKuliah: ['mataKuliah'],
  semester: ['semester'],
  tahunAkademik: ['tahunAkademik'],
};

const listKurikulum = async (query) => {
  const { page, limit, offset } = getPagination(query);
  const where = {};
  if (query.search) {
    where[Op.or] = [
      { kode: { [Op.like]: `%${query.search}%` } },
      { mataKuliah: { [Op.like]: `%${query.search}%` } },
    ];
  }

  const { rows, count } = await Kurikulum.findAndCountAll({
    where,
    limit,
    offset,
    order: resolveOrder(query, SORTABLE_COLUMNS, [['id', 'DESC']]),
  });
  return { data: rows, meta: getPagingMeta(count, page, limit) };
};

const getKurikulumById = async (id) => {
  const item = await Kurikulum.findByPk(id);
  if (!item) throw new ApiError(404, 'Data kurikulum tidak ditemukan');
  return item;
};

const createKurikulum = async (payload, actorId) => {
  return Kurikulum.create({ ...payload, createdBy: actorId, updatedBy: actorId });
};

const updateKurikulum = async (id, payload, actorId) => {
  const item = await getKurikulumById(id);
  await item.update({ ...payload, updatedBy: actorId });
  return item;
};

const deleteKurikulum = async (id) => {
  const item = await getKurikulumById(id);
  await item.update({ isDelete: true });
};

module.exports = { listKurikulum, getKurikulumById, createKurikulum, updateKurikulum, deleteKurikulum };
